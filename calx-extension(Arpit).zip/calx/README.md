# Calx — Browser Calculator Extension

A sleek, premium calculator extension for Chrome / Edge / Brave.

---

## 📦 Files

```
calx/
├── manifest.json   ← Extension config (MV3)
├── popup.html      ← UI layout
├── popup.css       ← Styling
├── popup.js        ← Calculator logic
├── icon16.png      ← Toolbar icon
├── icon48.png      ← Extension page icon
└── icon128.png     ← Chrome Web Store icon
```

---

## 🚀 How to Install (Chrome / Edge / Brave)

1. **Download** and unzip the `calx` folder to your computer
2. Open your browser and go to:
   - Chrome → `chrome://extensions`
   - Edge   → `edge://extensions`
   - Brave  → `brave://extensions`
3. Toggle **Developer mode** ON (top-right switch)
4. Click **"Load unpacked"**
5. Select the `calx` folder
6. Done! The **Calx** icon will appear in your toolbar.
   - Pin it by clicking the puzzle piece 🧩 → pin Calx

---

## ✨ Features

| Feature         | How to use                          |
|----------------|--------------------------------------|
| Basic ops      | Click buttons or use keyboard        |
| Percentage     | `%` key or button                    |
| Square root    | `√` button or press `S`             |
| Square (x²)    | `x²` button                          |
| Reciprocal     | `1/x` button                         |
| Backspace      | `⌫` button or `Backspace` key       |
| Negate         | `+/−` button                         |
| Chain ops      | Naturally chains (e.g. 2+3×4)        |
| History        | Click the grid icon (top-right)      |
| Keyboard       | Full keyboard support                |

### Keyboard shortcuts
| Key              | Action     |
|-----------------|------------|
| `0–9`           | Digits     |
| `+ - * /`       | Operators  |
| `Enter` / `=`   | Equals     |
| `Backspace`     | Delete     |
| `Escape`        | Clear      |
| `%`             | Percent    |
| `S`             | Square root|

---

## 🎨 Design

Dark-premium aesthetic with Space Mono for display, Syne for UI.
Amber accent · Ripple feedback · Animated history panel.
